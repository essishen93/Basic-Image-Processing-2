//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to do the Sand vs Non-sand classification by both SVM and MMD+PCA
/////////////////////////////////////////////////////////////////////
//min_mean.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>   
#include <opencv2/opencv.hpp>
#include "functions.h"
using namespace cv;
using namespace std;

void min_mean(Mat &feature_vector_3, Mat &feature_test_3,Mat &decision,Mat &decision_test)
{
	int p=0,q=0;
    float mean_g=0,sum_mean_g=0;
	float varn_g=0,sum_varn_g=0;
	float mean_s=0,sum_mean_s=0;
	float varn_s=0,sum_varn_s=0;
	float sum_grass=0,dis_grass=0;
	float sum_straw=0,dis_straw=0;

	Mat feature_vector_grass(36,3,CV_32FC1);  //Grass
	Mat feature_vector_straw(36,3,CV_32FC1);  //Not grass
    Mat grass(2,3,CV_32FC1);
	Mat straw(2,3,CV_32FC1);

	for (p=0;p<72;p++)
		for (q=0;q<3;q++)
		{
			if (p<36)
				feature_vector_grass.at<float>(p,q)=feature_vector_3.at<float>(p,q);	
			else 
		        feature_vector_straw.at<float>(p-36,q)=feature_vector_3.at<float>(p,q);
		}

    for (q=0;q<3;q++)
	{
		mean_g=0;sum_mean_g=0;
		mean_s=0;sum_mean_s=0;
		for (p=0;p<36;p++)
		{
			sum_mean_g+=feature_vector_grass.at<float>(p,q);
			sum_mean_s+=feature_vector_straw.at<float>(p,q);
		}
		mean_g=sum_mean_g/36;
		mean_s=sum_mean_s/36;
		grass.at<float>(0,q)=mean_g;
		straw.at<float>(0,q)=mean_s;
	}

	for (q=0;q<3;q++)
	{
		varn_g=0;sum_varn_g=0;
		varn_s=0;sum_varn_s=0;
		for (p=0;p<36;p++)
		{
			sum_varn_g+=(feature_vector_grass.at<float>(p,q)-grass.at<float>(0,q))*(feature_vector_grass.at<float>(p,q)-grass.at<float>(0,q));
			sum_varn_s+=(feature_vector_straw.at<float>(p,q)-straw.at<float>(0,q))*(feature_vector_straw.at<float>(p,q)-straw.at<float>(0,q));
		}
		varn_g=sum_varn_g/35;
		varn_s=sum_varn_s/35;
		grass.at<float>(1,q)=varn_g;
		straw.at<float>(1,q)=varn_s;
	}

	for (p=0;p<72;p++)
	{
	  for (q=0;q<3;q++)
		{
			if (feature_vector_3.at<float>(p,q)==grass.at<float>(0,q))
				sum_grass+=0;
			else
			    sum_grass+=(feature_vector_3.at<float>(p,q)-grass.at<float>(0,q))*(feature_vector_3.at<float>(p,q)-grass.at<float>(0,q))/grass.at<float>(1,q);

			if (feature_vector_3.at<float>(p,q)==straw.at<float>(0,q))
				sum_straw+=0;
			else
			    sum_straw+=(feature_vector_3.at<float>(p,q)-straw.at<float>(0,q))*(feature_vector_3.at<float>(p,q)-straw.at<float>(0,q))/straw.at<float>(1,q);
			
		}
		dis_grass=abs(sum_grass);
		dis_straw=abs(sum_straw);
		if (dis_grass>dis_straw)
			decision.at<uchar>(p,0)=0;
		else
			decision.at<uchar>(p,0)=1;
	}
	sum_grass=0;
	sum_straw=0;



	for (p=0;p<24;p++)
	{
	  for (q=0;q<3;q++)
		{
			if (feature_test_3.at<float>(p,q)==grass.at<float>(0,q))
				sum_grass+=0;
			else
			    sum_grass+=(feature_test_3.at<float>(p,q)-grass.at<float>(0,q))*(feature_test_3.at<float>(p,q)-grass.at<float>(0,q))/grass.at<float>(1,q);

			if (feature_test_3.at<float>(p,q)==straw.at<float>(0,q))
				sum_straw+=0;
			else
			    sum_straw+=(feature_test_3.at<float>(p,q)-straw.at<float>(0,q))*(feature_test_3.at<float>(p,q)-straw.at<float>(0,q))/straw.at<float>(1,q);
			
		}
		dis_grass=abs(sum_grass);
		dis_straw=abs(sum_straw);
		if (dis_grass>dis_straw)
			decision_test.at<uchar>(p,0)=0;
		else
			decision_test.at<uchar>(p,0)=1;
	}
}