//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (b)
//This code is to use the Canny Edge Detection to get the edge map
/////////////////////////////////////////////////////////////////////
//functions.h
/////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONS_CPP_
#define _FUNCTIONS_CPP_
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
using namespace cv;

void get_gray(char *name_rgb,char *name_gray,Mat &In_Image);

#endif
