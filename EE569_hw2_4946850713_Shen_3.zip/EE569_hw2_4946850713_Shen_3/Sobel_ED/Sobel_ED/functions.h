//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (a)
//This code is to use the Sobel Edge Detection and Non Maximum Supression to get the edge map
/////////////////////////////////////////////////////////////////////
//functions.h
/////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONS_CPP_
#define _FUNCTIONS_CPP_
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
using namespace cv;

void get_gray(char *name_rgb,char *name_gray,Mat &In_Image);
void sobel_ed(Mat &In_Image,Mat &Grad_Map_10,Mat &Grad_Map_15,char *name_edge_10,char *name_edge_15,Mat &sobel_x,Mat &sobel_y);
void nms_ed(Mat &In_Image,char *name_nms_10,char *name_nms_15,Mat &sobel_x,Mat &sobel_y);

#endif
