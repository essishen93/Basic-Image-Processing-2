//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 2 : (a)
//This code is to use the Sobel Edge Detection and Non Maximum Supression to get the edge map
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONS_CPP_
#define _FUNCTIONS_CPP_
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
using namespace cv;

void get_FV(char *name,Mat &feature_vector,int nsample,int feature);
void get_normal(Mat &feature_vector25,int h);
void min_mean(Mat &feature_vector_3,Mat &feature_test_3,Mat &decision,Mat &decision_test);

#endif
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
#include "functions.h"
using namespace cv;
using namespace std;

const int Size_H=321;   //the height of image
const int Size_W=481;   //the width of image
const int R=1;         //the radius of filtering window
int edgeThresh = 200;

void get_gray(char *name_rgb,char *name_gray,Mat &In_Image);
void sobel_ed(Mat &In_Image,Mat &Grad_Map_10,Mat &Grad_Map_15,char *name_edge_10,char *name_edge_15,Mat &sobel_x,Mat &sobel_y);
void nms_ed(Mat &In_Image,char *name_nms_10,char *name_nms_15,Mat &sobel_x,Mat &sobel_y);

int main()
{
    Mat In_Image_Farm(Size_H,Size_W,CV_8UC1);                 //the gray input image
    Mat In_Image_Cgar(Size_H,Size_W,CV_8UC1);                 //the gray input image
    
    Mat Grad_Map_Farm_10(Size_H,Size_W,CV_8UC1);                 //the gradient map of  input image (10%)
    Mat Grad_Map_Farm_15(Size_H,Size_W,CV_8UC1);                 //the gradient map of  input image (15%)
    
    Mat Grad_Map_Cgar_10(Size_H,Size_W,CV_8UC1);                 //the gradient map of  input image (10%)
    Mat Grad_Map_Cgar_15(Size_H,Size_W,CV_8UC1);                 //the gradient map of  input image (15%)

    char namef_rgb[]="Farm.raw";
    char namef_gray[]="Farm_gray.raw";
    char namef_edge_10[]="Farm_edge_10.raw";
    char namef_edge_15[]="Farm_edge_15.raw";
    char namef_edge_nms_10[]="Farm_edge_nms_10.raw";
    char namef_edge_nms_15[]="Farm_edge_nms_15.raw";
    
    char namec_rgb[]="Cougar.raw";
    char namec_gray[]="Cougar_gray.raw";
    char namec_edge_10[]="Cougar_edge_10.raw";
    char namec_edge_15[]="Cougar_edge_15.raw";
    char namec_edge_nms_10[]="Cougar_edge_nms_10.raw";
    char namec_edge_nms_15[]="Cougar_edge_nms_15.raw";
    
    //RGB to Gray
    get_gray(namef_rgb,namef_gray,In_Image_Farm);   //rgb to gray
    get_gray(namec_rgb,namec_gray,In_Image_Cgar);   //rgb to gray
   
    //generating the matrix of Sobel's mask
    double sobel_xmask[2*R+1][2*R+1]={{-1,0,1},{-2,0,2},{-1,0,1}};
    double sobel_ymask[2*R+1][2*R+1]={{-1,-2,-1},{0,0,0},{1,2,1}};
    Mat sobel_x(3,3,CV_64FC1,sobel_xmask);
    Mat sobel_y(3,3,CV_64FC1,sobel_ymask);
    
    //use 10% and 15% thresholds to get edge image
    sobel_ed(In_Image_Farm,Grad_Map_Farm_10,Grad_Map_Farm_15,namef_edge_10,namef_edge_15,sobel_x,sobel_y);
    sobel_ed(In_Image_Cgar,Grad_Map_Cgar_10,Grad_Map_Cgar_15,namec_edge_10,namec_edge_15,sobel_x,sobel_y);
    
    //use Non Maximum Supress
    nms_ed(In_Image_Farm,namef_edge_nms_10,namef_edge_nms_15,sobel_x,sobel_y);
    nms_ed(In_Image_Cgar,namec_edge_nms_10,namec_edge_nms_15,sobel_x,sobel_y);
    
    cout<<"The end"<<endl;
    getchar();
    return 0;
    
}
