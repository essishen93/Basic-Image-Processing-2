//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to do the Straw vs Non-straw classification by both SVM and MMD+PCA
/////////////////////////////////////////////////////////////////////
//functions.h
/////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONS_CPP_
#define _FUNCTIONS_CPP_  
#include <opencv2/core/core.hpp>   
#include <opencv2/opencv.hpp>
using namespace cv;

void get_FV(char *name,Mat &feature_vector,int nsample,int feature);
void get_normal(Mat &feature_vector25,int h);
void min_mean(Mat &feature_vector_3,Mat &feature_test_3,Mat &decision,Mat &decision_test);

#endif 