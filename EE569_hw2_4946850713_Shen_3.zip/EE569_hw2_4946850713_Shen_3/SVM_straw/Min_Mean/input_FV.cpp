//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to do the Straw vs Non-straw classification by both SVM and MMD+PCA
/////////////////////////////////////////////////////////////////////
//input_FV.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>   
#include <opencv2/opencv.hpp>
#include "functions.h"
using namespace cv;
using namespace std;


void get_FV(char *name,Mat &feature_vector,int nsample,int feature)
{
	int p=0,q=0;
	ifstream file(name,ios_base::in);
	if (!file)
	{
		cout<<"open failed"<<endl;
		exit(1);	
	}
	for (p=0;p<nsample;p++)
		for(q=0;q<feature;q++)
			file>>feature_vector.at<float>(p,q);
	file.close();
}
