//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (a)
//This code is texture classification by LDA+Minimum Mean Distance
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
using namespace cv;
using namespace std;

class sub_LDA:public cv::LDA
{
public:
    sub_LDA(InputArrayOfArrays src, InputArray labels,int num_components = 0){LDA(src,labels,num_components);_dataAsRow=true;}
};

//input feature vector
void get_FV(char *name,Mat &feature_vector,int nsample,int feature)
{
    int p=0,q=0;
    ifstream file(name,ios_base::in);
    if (!file)
    {
        cout<<"Cannot open failed"<<endl;
        exit(1);
    }
    for (p=0;p<nsample;p++)
        for(q=0;q<feature;q++)
            file>>feature_vector.at<float>(p,q);
    file.close();
}


int main()
{
    //the cordinates
    int p=0,q=0;
    Mat feature_vector_grass(36,25,CV_32FC1);
    Mat feature_vector_straw(36,25,CV_32FC1);
    Mat feature_vector_unknown(24,25,CV_32FC1);
    Mat feature_vector_25(72,25,CV_32FC1);  //feature vector
    Mat feature_vector_1(72,1,CV_32FC1);    //feature vector
    Mat feature_vector_unknown_1(24,1,CV_32FC1);
    
    char name1[]="feature_vector_grass.txt";
    char name2[]="feature_vector_straw.txt";
    char name3[]="feature_vector_unknown.txt";
    
    //input feature vector
    get_FV(name1,feature_vector_grass,36,25);
    get_FV(name2,feature_vector_straw,36,25);
    get_FV(name3,feature_vector_unknown,24,25);
    
    for (p=0;p<72;p++)
        for (q=0;q<25;q++)
        {
            if (p<36)
                feature_vector_25.at<float>(p,q)=feature_vector_grass.at<float>(p,q);
            else
                feature_vector_25.at<float>(p,q)=feature_vector_straw.at<float>(p-36,q);
        }
    
    //int i=0;
    vector<int>labels;
    //labels.resize(feature_vector_25.rows);
    for(int i=0;i<feature_vector_25.rows;i++)
    {
        if(i<feature_vector_25.rows/2)
        {
            labels.push_back(0);
        }
        else
        {
            labels.push_back(1);
        }
    }
  
    //LDA
    sub_LDA lda(feature_vector_25,labels);
    lda.compute(feature_vector_25,labels);
   
    feature_vector_1=lda.project(feature_vector_25);
    feature_vector_unknown_1=lda.project(feature_vector_unknown);
    
    //using the Minimum Mean distance classfier to unknown samples
    double sum_grass=0,sum_straw=0;
    double mean_grass=0,mean_straw=0;
    double varn_grass=0,sum_varn_grass=0;
    double varn_straw=0,sum_varn_straw=0;
    double dis_grass=0,dis_straw=0;
    for (p=0;p<72;p++)
    {
        if (p<36)
            sum_grass+=feature_vector_1.at<double>(p,0);
        if (p>35 && p<72)
            sum_straw+=feature_vector_1.at<double>(p,0);
    }
    mean_grass=sum_grass/36;
    mean_straw=sum_straw/36;
    
    for (p=0;p<72;p++)
    {
        if (p<36)
            sum_varn_grass+=(feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass);
        else
            sum_varn_straw+=(feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw);
    }
    varn_grass=sum_varn_grass/36;
    varn_straw=sum_varn_straw/36;
    
    char nameg[]="grass_01.raw";
    char names[]="straw_01.raw";
    char nameu[]="unknown_01.raw";
    int num=0;
    cout<<endl;
    cout<<"The results for testing image:"<<endl;
    cout<<endl;
    for (p=0;p<24;p++)
    {
        dis_grass=sqrt((feature_vector_unknown_1.at<double>(p,0)-mean_grass)*(feature_vector_unknown_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_unknown_1.at<double>(p,0)-mean_straw)*(feature_vector_unknown_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p+1;
        nameu[8]=48+(int)(num/10);
        nameu[9]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<nameu<<" is straw"<<endl;
        else
            cout<<nameu<<" is grass"<<endl;
    }
    
    cout<<endl;
    cout<<"The results for trainning image:"<<endl;
    cout<<endl;
    for (p=0;p<36;p++)
    {
        dis_grass=sqrt((feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p+1;
        nameg[6]=48+(int)(num/10);
        nameg[7]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<nameg<<" is straw"<<endl;
        else
            cout<<nameg<<" is grass"<<endl;
    }
    
    cout<<endl;
    for (p=36;p<72;p++)
    {
        dis_grass=sqrt((feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p-35;
        names[6]=48+(int)(num/10);
        names[7]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<names<<" is straw"<<endl;
        else
            cout<<names<<" is grass"<<endl;
    }
    cout<<"the end"<<endl;
    
    waitKey (0);
    getchar();
    return 0;
    
}

