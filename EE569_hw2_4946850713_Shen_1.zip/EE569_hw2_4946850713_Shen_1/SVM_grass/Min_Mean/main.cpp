//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to do the Grass vs Non-grass classification by both SVM and MMD+PCA
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>   
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
#include "functions.h"
using namespace cv;
using namespace std;

class sub_LDA:public cv::LDA
{
public:
	sub_LDA(InputArrayOfArrays src, InputArray labels,int num_components = 0){LDA(src,labels,num_components);_dataAsRow=true;}
};

void get_FV(char *name,Mat &feature_vector,int nsample,int feature);
void min_mean(Mat &feature_vector_3,Mat &feature_test_3,Mat &decision,Mat &decision_test);

int main()
{
	//the cordinates 
	int p=0,q=0;
	Mat feature_vector_grass(48,25,CV_32FC1);
	Mat feature_vector_straw(48,25,CV_32FC1); 
	Mat feature_vector_leather(48,25,CV_32FC1); 
	Mat feature_vector_sand(48,25,CV_32FC1);
	Mat feature_vector_test_25(24,25,CV_32FC1);
	Mat feature_vector_test_3(24,3,CV_32FC1);

	Mat feature_vector_25(72,25,CV_32FC1);  //feature vector
	Mat feature_vector_3(72,3,CV_32FC1);    //feature vector

	Mat labels(72,1,CV_32FC1);    
	Mat labels_test(24,1,CV_32FC1); 

	char name1[]="feature_vector_grass.txt";
	char name2[]="feature_vector_straw.txt";
	char name3[]="feature_vector_leather.txt";
	char name4[]="feature_vector_sand.txt";

	//input feature vector
	get_FV(name1,feature_vector_grass,48,25);
	get_FV(name2,feature_vector_straw,48,25);
	get_FV(name3,feature_vector_leather,48,25);
	get_FV(name3,feature_vector_sand,48,25);


	//set up the testing data
	for (p=0;p<24;p++)
		for (q=0;q<25;q++)
		{
			if (p<12)
				feature_vector_test_25.at<float>(p,q)=feature_vector_grass.at<float>(p+36,q);	
			else if (p>11 && p<16)
		        feature_vector_test_25.at<float>(p,q)=feature_vector_straw.at<float>(p+32,q);
			else if (p>15 && p<20)
				feature_vector_test_25.at<float>(p,q)=feature_vector_leather.at<float>(p+28,q);
			else
				feature_vector_test_25.at<float>(p,q)=feature_vector_sand.at<float>(p+24,q);
		}
	
	//Grass vs Non-grass
	//set up the trainning data
	for (p=0;p<72;p++)
		for (q=0;q<25;q++)
		{
			if (p<36)
				feature_vector_25.at<float>(p,q)=feature_vector_grass.at<float>(p,q);	
			else if (p>35 && p<48)
		        feature_vector_25.at<float>(p,q)=feature_vector_straw.at<float>(p-36,q);
			else if (p>47 && p<60)
				feature_vector_25.at<float>(p,q)=feature_vector_leather.at<float>(p-48,q);
			else
				feature_vector_25.at<float>(p,q)=feature_vector_sand.at<float>(p-60,q);
		}
	//set up the labels
	for (p=0;p<72;p++)
	{
		if (p<36)
			labels.at<float>(p,0)=1.0;
		else
			labels.at<float>(p,0)=-1.0;
	}
	
	//PCA
	//dimension reducation for training samples
	cv::PCA pca(feature_vector_25,cv::Mat(),CV_PCA_DATA_AS_ROW,3);  //25-D to 1-D
	pca.project(feature_vector_25,feature_vector_3);                //the new 3-D feature vector has the same columns with 25-D's
	pca.project(feature_vector_test_25,feature_vector_test_3);
	

	//set up SVM's parameters
	CvSVMParams params;
    params.svm_type=CvSVM::C_SVC;
    params.kernel_type=CvSVM::LINEAR;
    params.term_crit=cvTermCriteria(CV_TERMCRIT_ITER,100,1e-6);

	//train the SVM by training sample
	CvSVM SVM;
	Mat m1,m2;
	SVM.train(feature_vector_25,labels,m1,m2,params);

	//classify the trainning data
	float response=0;
	char nameg[]="grass_01.raw";
	char names[]="straw_01.raw";
	char namel[]="leather_01.raw";
	char named[]="sand_01.raw";
	int num=0;
	cout<<"******The results from SVM******"<<endl; 
	cout<<"******training sample******"<<endl; 
	for (p=0;p<72;p++)
	{
		if (p<36)
		{
		num=p+1;
		nameg[6]=48+(int)(num/10);
		nameg[7]=48+num%10;
		cout<<nameg<<" ";
		}
		else if (p>35 && p<48)
		{
		num=p-35;
		names[6]=48+(int)(num/10);
		names[7]=48+num%10;
		cout<<names<<" ";
		}
		else if (p>47 && p<60)
		{
		num=p-47;
		namel[8]=48+(int)(num/10);
		namel[9]=48+num%10;
		cout<<namel<<" ";
		}
		else
		{
		num=p-59;
		named[5]=48+(int)(num/10);
		named[6]=48+num%10;
		cout<<named<<" ";
		}
		response=SVM.predict(feature_vector_25.row(p));
		if (response==1)
			cout<<"is grass"<<endl;
		if (response==-1)
			cout<<"is NOT grass"<<endl;
	}

	//classify the testing data
	cout<<endl; 
	cout<<"******testing sample******"<<endl; 
	for (p=0;p<24;p++)
	{
		if (p<12)
		{
		num=p+37;
		nameg[6]=48+(int)(num/10);
		nameg[7]=48+num%10;
		cout<<nameg<<" ";
		}
		else if (p>11 && p<16)
		{
		num=p+33;
		names[6]=48+(int)(num/10);
		names[7]=48+num%10;
		cout<<names<<" ";
		}
		else if (p>15 && p<20)
		{
		num=p+29;
		namel[8]=48+(int)(num/10);
		namel[9]=48+num%10;
		cout<<namel<<" ";
		}
		else
		{
		num=p+25;
		named[5]=48+(int)(num/10);
		named[6]=48+num%10;
		cout<<named<<" ";
		}
		response=SVM.predict(feature_vector_test_25.row(p));
		if (response==1)
			cout<<"is grass"<<endl;
		if (response==-1)
			cout<<"is NOT grass"<<endl;
	}

	//The results from Minimum Mean Distance
	Mat decision(72,1,CV_8UC1);
	Mat decision_test(24,1,CV_8UC1);
	min_mean(feature_vector_3,feature_vector_test_3,decision,decision_test);  //Minimum Mean Distance
	//cout<<decision<<endl;
	cout<<endl; 
	cout<<"******The results from Minimum Mean Distance******"<<endl; 
	cout<<"******training sample******"<<endl;
	for (p=0;p<72;p++)
	{
		if (p<36)
		{
		num=p+1;
		nameg[6]=48+(int)(num/10);
		nameg[7]=48+num%10;
		cout<<nameg<<" ";
		}
		else if (p>35 && p<48)
		{
		num=p-35;
		names[6]=48+(int)(num/10);
		names[7]=48+num%10;
		cout<<names<<" ";
		}
		else if (p>47 && p<60)
		{
		num=p-47;
		namel[8]=48+(int)(num/10);
		namel[9]=48+num%10;
		cout<<namel<<" ";
		}
		else
		{
		num=p-59;
		named[5]=48+(int)(num/10);
		named[6]=48+num%10;
		cout<<named<<" ";
		}
		//response=SVM.predict(feature_vector_grass_3.row(p));
		if (decision.at<uchar>(p,0)==1)
			cout<<"is grass"<<endl;
		if (decision.at<uchar>(p,0)==0)
			cout<<"is NOT grass"<<endl;
	}

	//classify the testing data
	cout<<endl; 
	cout<<"******testing sample******"<<endl; 
	for (p=0;p<24;p++)
	{
		if (p<12)
		{
		num=p+37;
		nameg[6]=48+(int)(num/10);
		nameg[7]=48+num%10;
		cout<<nameg<<" ";
		}
		else if (p>11 && p<16)
		{
		num=p+33;
		names[6]=48+(int)(num/10);
		names[7]=48+num%10;
		cout<<names<<" ";
		}
		else if (p>15 && p<20)
		{
		num=p+29;
		namel[8]=48+(int)(num/10);
		namel[9]=48+num%10;
		cout<<namel<<" ";
		}
		else
		{
		num=p+25;
		named[5]=48+(int)(num/10);
		named[6]=48+num%10;
		cout<<named<<" ";
		}
		if (decision_test.at<uchar>(p,0)==1)
			cout<<"is grass"<<endl;
		if (decision_test.at<uchar>(p,0)==0)
			cout<<"is NOT grass"<<endl;
	}
    waitKey (0);
	getchar();
    return 0;
 
}
