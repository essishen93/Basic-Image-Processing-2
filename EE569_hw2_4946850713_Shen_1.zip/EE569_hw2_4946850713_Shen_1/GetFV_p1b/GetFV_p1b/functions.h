//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to get 25-D feature vectors of the image
/////////////////////////////////////////////////////////////////////
//functions.h
/////////////////////////////////////////////////////////////////////
#ifndef _FUNCTIONS_CPP_
#define _FUNCTIONS_CPP_
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
using namespace cv;

double get_FV(char *name,Mat &laws_filter,int Size_H,int Size_W,int R);
void get_normal(Mat &feature_vector25,int h);

#endif
