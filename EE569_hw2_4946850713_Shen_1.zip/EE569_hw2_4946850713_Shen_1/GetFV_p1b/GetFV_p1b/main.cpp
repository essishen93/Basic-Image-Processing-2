//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (b)
//This code is to get 25-D feature vectors of the image
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
#include "functions.h"
using namespace cv;
using namespace std;

const int Size_H=128;   //the height of image
const int Size_W=128;   //the width of image
const int R=2;         //the radius of filtering window

double get_FV(char *name,Mat &laws_filter,int Size_H,int Size_W,int R);
void get_normal(Mat &feature_vector25,int h);

int main()
{
    //the cordinates of Laws' filter
    int pF=0,qF=0;
    int p=0,q=0;
    Mat window_filter(5,5,CV_64FC1);           //Laws' filter window/mask
    Mat feature_vector_grass(48,25,CV_64FC1);  //feature vector
    Mat feature_vector_straw(48,25,CV_64FC1);  //feature vector
    Mat feature_vector_leather(48,25,CV_64FC1);  //feature vector
    Mat feature_vector_sand(48,25,CV_64FC1);  //feature vector
    Mat feature_vector_all(192,25,CV_64FC1);  //feature vector
    
    //generating the matrix of Laws' filter
    float laws_array[2*R+1][2*R+1]={{1,4,6,4,1},{-1,-2,0,2,1},{-1,0,2,0,-1},{-1,2,0,-2,1},{1,-4,6,-4,1}};
    Mat laws_filter(5,5,CV_64FC1);
    //int p=0,q=0;
    for (p=0;p<2*R+1;p++)
        for (q=0;q<2*R+1;q++)
            laws_filter.at<double>(p,q)=laws_array[p][q];
    
    int ch=0,num=0;
    char name1[]="grass_01.raw";
    char name2[]="straw_01.raw";
    char name3[]="leather_01.raw";
    char name4[]="sand_01.raw";
    for (ch=0;ch<48;ch++)
    {
        //change the name of image to get the next
        num=ch+1;
        name1[6]=48+(int)(num/10);
        name1[7]=48+num%10;
        name2[6]=48+(int)(num/10);
        name2[7]=48+num%10;
        name3[8]=48+(int)(num/10);
        name3[9]=48+num%10;
        name4[5]=48+(int)(num/10);
        name4[6]=48+num%10;
        cout<<name1<<"   "<<name2<<"   "<<name3<<"   "<<name4<<"  processing..."<<endl;
        
        //go through the Filter Bank and get the feature vector
        for (pF=0;pF<5;pF++)
            for (qF=0;qF<5;qF++)
            {
                //one of 25 Laws' filters
                window_filter=laws_filter.row(pF).t()*laws_filter.row(qF);
                feature_vector_grass.at<double>(ch,pF*5+qF)=get_FV(name1,window_filter,Size_H,Size_W,R);   //obtian feature vector
                feature_vector_straw.at<double>(ch,pF*5+qF)=get_FV(name2,window_filter,Size_H,Size_W,R);   //obtian feature vector
                feature_vector_leather.at<double>(ch,pF*5+qF)=get_FV(name3,window_filter,Size_H,Size_W,R);   //obtian feature vector
                feature_vector_sand.at<double>(ch,pF*5+qF)=get_FV(name4,window_filter,Size_H,Size_W,R);   //obtian feature vector
            }
    }
    
    for (p=0;p<192;p++)
        for(q=0;q<25;q++)
        {
            if (p<48)
                feature_vector_all.at<double>(p,q)=feature_vector_grass.at<double>(p,q);
            else if (p>47 && p<96)
                feature_vector_all.at<double>(p,q)=feature_vector_straw.at<double>(p-48,q);
            else if (p>95 && p<144)
                feature_vector_all.at<double>(p,q)=feature_vector_leather.at<double>(p-96,q);
            else
                feature_vector_all.at<double>(p,q)=feature_vector_sand.at<double>(p-144,q);
        }
    
    get_normal(feature_vector_all,192);
    
    for (p=0;p<192;p++)
        for(q=0;q<25;q++)
        {
            if (p<48)
                feature_vector_grass.at<double>(p,q)=feature_vector_all.at<double>(p,q);
            else if (p>47 && p<96)
                feature_vector_straw.at<double>(p-48,q)=feature_vector_all.at<double>(p,q);
            else if (p>95 && p<144)
                feature_vector_leather.at<double>(p-96,q)=feature_vector_all.at<double>(p,q);
            else
                feature_vector_sand.at<double>(p-144,q)=feature_vector_all.at<double>(p,q);
        }
    
    ofstream Fgfile("feature_vector_grass.txt",ios_base::out);
    if (!Fgfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    ofstream Fsfile("feature_vector_straw.txt",ios_base::out);
    if (!Fsfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream Flfile("feature_vector_leather.txt",ios_base::out);
    if (!Flfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    ofstream Fdfile("feature_vector_sand.txt",ios_base::out);
    if (!Fdfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    for (p=0;p<48;p++)
        for(q=0;q<25;q++)
        {
            Fgfile<<feature_vector_grass.at<double>(p,q)<<endl;
            Fsfile<<feature_vector_straw.at<double>(p,q)<<endl;
            Flfile<<feature_vector_leather.at<double>(p,q)<<endl;
            Fdfile<<feature_vector_sand.at<double>(p,q)<<endl;
            
        }
    
    //cout<<"the end"<<endl;
    Fgfile.close();
    Fsfile.close();
    Flfile.close();
    Fdfile.close();
    
    
    ofstream gfile("grass.txt",ios_base::out);
    if (!gfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    ofstream sfile("straw.txt",ios_base::out);
    if (!sfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream lfile("leather.txt",ios_base::out);
    if (!lfile)
    {
        cout<<"open failed"<<endl;
        exit(1);	
    }
    
    ofstream dfile("sand.txt",ios_base::out);
    if (!dfile)
    {
        cout<<"open failed"<<endl;
        exit(1);	
    }
    
    for (p=0;p<36;p++)
        for(q=0;q<25;q++)
        {
            gfile<<feature_vector_grass.at<double>(p,q);
            sfile<<feature_vector_straw.at<double>(p,q);
            lfile<<feature_vector_leather.at<double>(p,q);
            dfile<<feature_vector_sand.at<double>(p,q);
            if (q==24)
            {
                gfile<<endl;
                sfile<<endl;
                lfile<<endl;
                dfile<<endl;
            }
            else 
            {
                gfile<<" ";
                sfile<<" ";
                lfile<<" ";
                dfile<<" ";
            }
        }
    
    gfile.close();
    sfile.close();
    lfile.close();
    dfile.close();
    cout<<"the end"<<endl;
    waitKey (0);
    getchar();
    return 0;
    
}

