#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>   
#include <opencv2/opencv.hpp>
#include "functions.h"
using namespace cv;
using namespace std;


void get_FV(char *name,Mat &feature_vector,int nsample,int feature)
{
	int p=0,q=0;
	ifstream file(name,ios_base::in);
	if (!file)
	{
		cout<<"open failed"<<endl;
		exit(1);	
	}
	for (p=0;p<nsample;p++)
		for(q=0;q<feature;q++)
			file>>feature_vector.at<double>(p,q);
	file.close();
}
