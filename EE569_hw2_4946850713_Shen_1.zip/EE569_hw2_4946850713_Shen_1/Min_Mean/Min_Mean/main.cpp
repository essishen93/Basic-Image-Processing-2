//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (a)
//This code is texture classification by Minimum Mean Distance
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
using namespace cv;
using namespace std;

void get_FV(char *name,Mat &feature_vector,int nsample,int feature)
{
    int p=0,q=0;
    ifstream file(name,ios_base::in);
    if (!file)
    {
        cout<<"CANNOT open failed"<<endl;
        exit(1);
    }
    for (p=0;p<nsample;p++)
        for(q=0;q<feature;q++)
            file>>feature_vector.at<double>(p,q);
    file.close();
}

int main()
{
    //the cordinates
    int p=0,q=0;
    double mean_g=0,sum_mean_g=0;
    double varn_g=0,sum_varn_g=0;
    double mean_s=0,sum_mean_s=0;
    double varn_s=0,sum_varn_s=0;
    double sum_grass=0,dis_grass=0;
    double sum_straw=0,dis_straw=0;
    
    Mat feature_vector_grass(36,25,CV_64FC1);
    Mat feature_vector_straw(36,25,CV_64FC1);
    Mat feature_vector_unknown(24,25,CV_64FC1);
    Mat grass(2,25,CV_64FC1);                      //mean and standard deviation from label "grass" image
    Mat straw(2,25,CV_64FC1);                      //mean and standard deviation from label "straw" image
    
    char name1[]="feature_vector_grass.txt";
    char name2[]="feature_vector_straw.txt";
    char name3[]="feature_vector_unknown.txt";
    
    //input feature vector
    get_FV(name1,feature_vector_grass,36,25);
    get_FV(name2,feature_vector_straw,36,25);
    get_FV(name3,feature_vector_unknown,24,25);
    
    for (q=0;q<25;q++)
    {
        mean_g=0;sum_mean_g=0;
        mean_s=0;sum_mean_s=0;
        for (p=0;p<36;p++)
        {
            sum_mean_g+=feature_vector_grass.at<double>(p,q);
            sum_mean_s+=feature_vector_straw.at<double>(p,q);
        }
        mean_g=sum_mean_g/36;
        mean_s=sum_mean_s/36;
        grass.at<double>(0,q)=mean_g;
        straw.at<double>(0,q)=mean_s;
    }
    
    for (q=0;q<25;q++)
    {
        varn_g=0;sum_varn_g=0;
        varn_s=0;sum_varn_s=0;
        for (p=0;p<36;p++)
        {
            sum_varn_g+=(feature_vector_grass.at<double>(p,q)-grass.at<double>(0,q))*(feature_vector_grass.at<double>(p,q)-grass.at<double>(0,q));
            sum_varn_s+=(feature_vector_straw.at<double>(p,q)-straw.at<double>(0,q))*(feature_vector_straw.at<double>(p,q)-straw.at<double>(0,q));
        }
        varn_g=sum_varn_g/35;
        varn_s=sum_varn_s/35;
        grass.at<double>(1,q)=varn_g;
        straw.at<double>(1,q)=varn_s;
    }
    //cout<<grass<<endl;
    //cout<<straw<<endl;
    
    
    char name[]="unknown_01.raw";
    int num=0;
    for (p=0;p<24;p++)
    {
        num=p+1;
        name[8]=48+(int)(num/10);
        name[9]=48+num%10;
        
        sum_grass=0;dis_grass=0;
        sum_straw=0;dis_straw=0;
        for (q=0;q<25;q++)
        {
            if (feature_vector_unknown.at<double>(p,q)==grass.at<double>(0,q))
                sum_grass+=0;
            else
                sum_grass+=(feature_vector_unknown.at<double>(p,q)-grass.at<double>(0,q))*(feature_vector_unknown.at<double>(p,q)-grass.at<double>(0,q))/grass.at<double>(1,q);
            
            if (feature_vector_unknown.at<double>(p,q)==straw.at<double>(0,q))
                sum_straw+=0;
            else
                sum_straw+=(feature_vector_unknown.at<double>(p,q)-straw.at<double>(0,q))*(feature_vector_unknown.at<double>(p,q)-straw.at<double>(0,q))/straw.at<double>(1,q);
            
        }
        dis_grass=abs(sum_grass);
        dis_straw=abs(sum_straw);
        if (dis_grass>dis_straw)
            cout<<name<<" is straw"<<endl;
        else
            cout<<name<<" is grass"<<endl;
    }
    
    cout<<endl;
    
    char nameg[]="grass_01.raw";
    for (p=0;p<36;p++)
    {
        num=p+1;
        nameg[6]=48+(int)(num/10);
        nameg[7]=48+num%10;
        
        sum_grass=0;dis_grass=0;
        sum_straw=0;dis_straw=0;
        for (q=0;q<25;q++)
        {
            if (feature_vector_grass.at<double>(p,q)==grass.at<double>(0,q))
                sum_grass+=0;
            else
                sum_grass+=(feature_vector_grass.at<double>(p,q)-grass.at<double>(0,q))*(feature_vector_grass.at<double>(p,q)-grass.at<double>(0,q))/grass.at<double>(1,q);
            if (feature_vector_grass.at<double>(p,q)==straw.at<double>(0,q))
                sum_straw+=0;
            else
                sum_straw+=(feature_vector_grass.at<double>(p,q)-straw.at<double>(0,q))*(feature_vector_grass.at<double>(p,q)-straw.at<double>(0,q))/straw.at<double>(1,q);
        }
        dis_grass=abs(sum_grass);
        dis_straw=abs(sum_straw);
        if (dis_grass>dis_straw)
            cout<<nameg<<" is straw"<<endl;
        else
            cout<<nameg<<" is grass"<<endl;
    }
    
    cout<<endl;
    
    char names[]="straw_01.raw";
    for (p=0;p<36;p++)
    {
        num=p+1;
        names[6]=48+(int)(num/10);
        names[7]=48+num%10;
        
        sum_grass=0;dis_grass=0;
        sum_straw=0;dis_straw=0;
        for (q=0;q<25;q++)
        {
            if (feature_vector_straw.at<double>(p,q)==grass.at<double>(0,q))
                sum_grass+=0;
            else
                sum_grass+=(feature_vector_straw.at<double>(p,q)-grass.at<double>(0,q))*(feature_vector_straw.at<double>(p,q)-grass.at<double>(0,q))/grass.at<double>(1,q);
            if (feature_vector_straw.at<double>(p,q)==straw.at<double>(0,q))
                sum_straw+=0;
            else
                sum_straw+=(feature_vector_straw.at<double>(p,q)-straw.at<double>(0,q))*(feature_vector_straw.at<double>(p,q)-straw.at<double>(0,q))/straw.at<double>(1,q);
        }
        dis_grass=abs(sum_grass);
        dis_straw=abs(sum_straw);
        if (dis_grass>dis_straw)
            cout<<names<<" is straw"<<endl;
        else
            cout<<names<<" is grass"<<endl;
    }
    
    waitKey (0);
    getchar();
    return 0;
    
}

