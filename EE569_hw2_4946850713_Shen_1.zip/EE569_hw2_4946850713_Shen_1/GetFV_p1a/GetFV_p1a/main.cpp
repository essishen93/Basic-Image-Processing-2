//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (a)
//This code is texture classification by Minimum Mean Distance, PCA and LDA
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
#include "functions.h"
using namespace cv;
using namespace std;

const int Size_H=128;   //the height of image
const int Size_W=128;   //the width of image
const int R=2;         //the radius of filtering window

double get_FV(char *name,Mat &laws_filter,int Size_H,int Size_W,int R);
void get_normal(Mat &feature_vector25,int h);

int main()
{
    //the cordinates of Laws' filter
    int pF=0,qF=0;
    int p=0,q=0;
    Mat window_filter(5,5,CV_64FC1);           //Laws' filter window/mask
    Mat feature_vector_grass(36,25,CV_64FC1);  //feature vector
    Mat feature_vector_straw(36,25,CV_64FC1);  //feature vector
    Mat feature_vector_unknown(24,25,CV_64FC1);  //feature vector
    Mat feature_vector_all(96,25,CV_64FC1);  //feature vector
    
    //generating the matrix of Laws' filter
    float laws_array[2*R+1][2*R+1]={{1,4,6,4,1},{-1,-2,0,2,1},{-1,0,2,0,-1},{-1,2,0,-2,1},{1,-4,6,-4,1}};
    Mat laws_filter(5,5,CV_64FC1);
    //int p=0,q=0;
    for (p=0;p<2*R+1;p++)
        for (q=0;q<2*R+1;q++)
            laws_filter.at<double>(p,q)=laws_array[p][q];
    
    int ch=0,num=0;
    char name1[]="grass_01.raw";
    char name2[]="straw_01.raw";
    char name3[]="unknown_01.raw";
    for (ch=0;ch<36;ch++)
    {
        //change the name of image to get the next
        num=ch+1;
        name1[6]=48+(int)(num/10);
        name1[7]=48+num%10;
        name2[6]=48+(int)(num/10);
        name2[7]=48+num%10;
        cout<<name1<<"   "<<name2<<"  processing..."<<endl;
        if (ch<24)
        {
            name3[8]=48+(int)(num/10);
            name3[9]=48+num%10;
            cout<<name3<<"  processing..."<<endl;
        }
        
        //go through the Filter Bank and get the feature vector
        for (pF=0;pF<5;pF++)
            for (qF=0;qF<5;qF++)
            {
                //one of 25 Laws' filters
                window_filter=laws_filter.row(pF).t()*laws_filter.row(qF);
                //cout<<window_filter<<endl;
                feature_vector_grass.at<double>(ch,pF*5+qF)=get_FV(name1,window_filter,Size_H,Size_W,R);   //obtian feature vector
                feature_vector_straw.at<double>(ch,pF*5+qF)=get_FV(name2,window_filter,Size_H,Size_W,R);   //obtian feature vector
                if (ch<24)
                    feature_vector_unknown.at<double>(ch,pF*5+qF)=get_FV(name3,window_filter,Size_H,Size_W,R);   //obtian feature vector
            }
    }
    for (p=0;p<96;p++)
        for(q=0;q<25;q++)
        {
            if (p<36)
                feature_vector_all.at<double>(p,q)=feature_vector_grass.at<double>(p,q);
            else if (p>35 && p<72)
                feature_vector_all.at<double>(p,q)=feature_vector_straw.at<double>(p-36,q);
            else
                feature_vector_all.at<double>(p,q)=feature_vector_unknown.at<double>(p-72,q);
        }
    
    get_normal(feature_vector_all,96);
    
    for (p=0;p<96;p++)
        for(q=0;q<25;q++)
        {
            if (p<36)
                feature_vector_grass.at<double>(p,q)=feature_vector_all.at<double>(p,q);
            else if (p>35 && p<72)
                feature_vector_straw.at<double>(p-36,q)=feature_vector_all.at<double>(p,q);
            else
                feature_vector_unknown.at<double>(p-72,q)=feature_vector_all.at<double>(p,q);
        }
    
    ofstream Fgfile("feature_vector_grass.txt",ios_base::out);
    if (!Fgfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    ofstream Fsfile("feature_vector_straw.txt",ios_base::out);
    if (!Fsfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    ofstream Fufile("feature_vector_unknown.txt",ios_base::out);
    if (!Fufile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    for (p=0;p<36;p++)
        for(q=0;q<25;q++)
        {
            Fgfile<<feature_vector_grass.at<double>(p,q)<<endl;
            Fsfile<<feature_vector_straw.at<double>(p,q)<<endl;
            if (p<24)
                Fufile<<feature_vector_unknown.at<double>(p,q)<<endl;
        }
    
    //cout<<"the end"<<endl;
    Fgfile.close();
    Fsfile.close();
    Fufile.close();
    
    
    ofstream gfile("grass.txt",ios_base::out);
    if (!gfile)
    {
        cout<<"open failed"<<endl;
        exit(1);
    }
    
    ofstream sfile("straw.txt",ios_base::out);
    if (!sfile)
    {
        cout<<"open failed"<<endl;
        exit(1);	
    }
    ofstream ufile("unknown.txt",ios_base::out);
    if (!ufile)
    {
        cout<<"open failed"<<endl;
        exit(1);	
    }
    
    for (p=0;p<36;p++)
        for(q=0;q<25;q++)
        {
            gfile<<feature_vector_grass.at<double>(p,q);
            sfile<<feature_vector_straw.at<double>(p,q);
            if (q==24)
            {
                gfile<<endl;
                sfile<<endl;
            }
            else 
            {
                gfile<<" ";
                sfile<<" ";
            }
            if (p<24)
            {
                ufile<<feature_vector_unknown.at<double>(p,q);
                if (q==24) ufile<<endl;
                else ufile<<" ";
            }
        }
    
    gfile.close();
    sfile.close();
    ufile.close();
    cout<<"the end"<<endl;
    waitKey (0);
    getchar();
    return 0;
    
}

