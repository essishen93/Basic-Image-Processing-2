//Name: Maoru Shen
//USC ID Number: 4946-8507-13
//USC Email: maorushe@usc.edu
//Submission Date: 10/11/2015
////////////////////////////////////////////////////////////////////
//Problem 1 : (a)
//This code is texture classification by PCA+Minimum Mean Distance
/////////////////////////////////////////////////////////////////////
//main.cpp
/////////////////////////////////////////////////////////////////////
#include <iostream>
#include <fstream>
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include <cmath>
#include <string>
using namespace cv;
using namespace std;


//input feature vector
void get_FV(char *name,Mat &feature_vector,int nsample,int feature)
{
    int p=0,q=0;
    ifstream file(name,ios_base::in);
    if (!file)
    {
        cout<<"Cannot open failed"<<endl;
        exit(1);
    }
    for (p=0;p<nsample;p++)
        for(q=0;q<feature;q++)
            file>>feature_vector.at<double>(p,q);
    file.close();
}

int main()
{
    //the cordinates
    int p=0,q=0;
    Mat feature_vector_grass(36,25,CV_64FC1);
    Mat feature_vector_straw(36,25,CV_64FC1);
    Mat feature_vector_unknown(24,25,CV_64FC1);
    Mat feature_vector_25(72,25,CV_64FC1);  //feature vector
    Mat feature_vector_1(72,1,CV_64FC1);    //feature vector
    Mat feature_vector_unknown_1(24,1,CV_64FC1);
    Mat eigen_vector(1,25,CV_64FC1);        //eigenvector from PCA
    
    char name1[]="feature_vector_grass.txt";
    char name2[]="feature_vector_straw.txt";
    char name3[]="feature_vector_unknown.txt";
    
    //input feature vector
    get_FV(name1,feature_vector_grass,36,25);
    get_FV(name2,feature_vector_straw,36,25);
    get_FV(name3,feature_vector_unknown,24,25);
    
    for (p=0;p<72;p++)
        for (q=0;q<25;q++)
        {
            if (p<36)
                feature_vector_25.at<double>(p,q)=feature_vector_grass.at<double>(p,q);
            else
                feature_vector_25.at<double>(p,q)=feature_vector_straw.at<double>(p-36,q);
        }
    
    
    //PCA
    //25-D to 1-D
    cv::PCA pca(feature_vector_25,cv::Mat(),CV_PCA_DATA_AS_ROW,1);
    //obtain eigenvector
    pca.eigenvectors.convertTo(eigen_vector,CV_64F);
    Mat projected(72,1,CV_64FC1);
    //the new 1-D feature vector has the same columns with 25-D's
    pca.project(feature_vector_25,projected);
    projected.convertTo(feature_vector_1,CV_64F);
    
    //Mat projected_test(72,1,CV_64FC1);
    pca.project(feature_vector_unknown,feature_vector_unknown_1);
    /*
     Mat temp(1,1,CV_64F);
     for (p=0;p<24;p++)
     {
     temp=feature_vector_unknown.row(p)*eigen_vector.t();
     feature_vector_unknown_1.at<double>(p,0)=temp.at<double>(0,0);
     }
     //cout<<feature_vector_25.col(1)<<endl;
     cout<<feature_vector_unknown_1<<endl;
     */
    //using the Minimum Mean distance classfier to unknown samples
    double sum_grass=0,sum_straw=0;
    double mean_grass=0,mean_straw=0;
    double varn_grass=0,sum_varn_grass=0;
    double varn_straw=0,sum_varn_straw=0;
    double dis_grass=0,dis_straw=0;
    for (p=0;p<72;p++)
    {
        if (p<36)
            sum_grass+=feature_vector_1.at<double>(p,0);
        if (p>35 && p<72)
            sum_straw+=feature_vector_1.at<double>(p,0);
    }
    mean_grass=sum_grass/36;
    mean_straw=sum_straw/36;
    
    for (p=0;p<72;p++)
    {
        if (p<36)
            sum_varn_grass+=(feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass);
        else
            sum_varn_straw+=(feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw);
    }
    varn_grass=sum_varn_grass/36;
    varn_straw=sum_varn_straw/36;
    
    char nameg[]="grass_01.raw";
    char names[]="straw_01.raw";
    char nameu[]="unknown_01.raw";
    
    cout<<endl;
    cout<<"The results for testing image:"<<endl;
    cout<<endl;
    int num=0;
    for (p=0;p<24;p++)
    {
        dis_grass=sqrt((feature_vector_unknown_1.at<double>(p,0)-mean_grass)*(feature_vector_unknown_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_unknown_1.at<double>(p,0)-mean_straw)*(feature_vector_unknown_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p+1;
        nameu[8]=48+(int)(num/10);
        nameu[9]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<nameu<<" is straw"<<endl;
        else
            cout<<nameu<<" is grass"<<endl;
    }
    
    cout<<endl;
    cout<<"The results for trainning image:"<<endl;
    cout<<endl;
    for (p=0;p<36;p++)
    {
        dis_grass=sqrt((feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p+1;
        nameg[6]=48+(int)(num/10);
        nameg[7]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<nameg<<" is straw"<<endl;
        else
            cout<<nameg<<" is grass"<<endl;
    }
    
    cout<<endl;
    for (p=36;p<72;p++)
    {
        dis_grass=sqrt((feature_vector_1.at<double>(p,0)-mean_grass)*(feature_vector_1.at<double>(p,0)-mean_grass)/varn_grass);   // distance with "grass"
        dis_straw=sqrt((feature_vector_1.at<double>(p,0)-mean_straw)*(feature_vector_1.at<double>(p,0)-mean_straw)/varn_straw);   // distance with "straw"
        num=p-35;
        names[6]=48+(int)(num/10);
        names[7]=48+num%10;
        if (dis_grass>dis_straw)
            cout<<names<<" is straw"<<endl;
        else
            cout<<names<<" is grass"<<endl;
    }
    
    cout<<"the end"<<endl;
    
    waitKey (0);
    getchar();
    return 0;
    
}

